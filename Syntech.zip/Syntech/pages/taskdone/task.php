<!DOCTYPE html>
<html>
<head>
    <style>
        
    /* Basic styling for the search bar */
    #search {
        padding: 8px;
        width: 200px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        margin-top: -5px;
        margin-left: 1050px;
        
    }

    /* Style the placeholder text */
    #search::placeholder {
        color: #999;
    }

    /* Style when the input is focused */
    #search:focus {
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }


         .rectangle {
            width: 300px;
            height: 700px;
            background-color: white; 
            padding: 10px;
            margin-top: 0px; 
            margin-left: 20px;
        }
        .rectangle2 {
            width: 1280px;
            height: 600px;
            background-color: white; 
            padding: 10px;
            margin-left: 350px;
            margin-top: 60px; 
            
        }
        .rectangle3 {
            width: 1280px;
            height: 50px;
            background-color: white; 
            padding: 10px;
            margin-left: 350px;
            margin-top: -710px; 
            
        }
        h1 {
            background: linear-gradient(90deg, red, white);
            color: transparent;
            text-align: center;
            margin: 0;
            padding: 20px 0; 
            font-size: 40px;
            font-family: "Rhodium Libre", Times, serif;
            -webkit-background-clip: text;
            background-clip: text;
        }
        h2{
            font-size: 20px;
        }
        h3{
            margin-top: -40px;
        }
        h4{
            margin-top: 0px;
        }

        table {
            border-collapse: collapse;
            width: 75%;
            background-color: white;
            margin-left: 350px;
            margin-top: 100px;
            
        }


        th, td {
            border: 2px solid #dddddd;
            text-align: left;
            padding: 8px;
            width: 80% 10% 10%;
            height: 40px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        

       
    </style>
</head>
<body>
   

   
            
        
    

    <div class="rectangle">
        <h2>Navigation</h2>
        
        <div class="nav-item" onclick="to_dash()">
    <a href="#dash" class="nav-link text-dark" id="dashLink">
        <i class="fas fa-list"></i> Dashboard
    </a>
</div>

      <div sclass="nav-item" onclick="to_task()">
        <a href="#task" class="nav-link text-dark" id="taskLink">
          <i class="fas fa-list"></i> Task Done
        </a>
      </div>
    </div>
    

    <div class="rectangle3">
    <form action="/search" method="get">
        <!-- 'action' attribute should point to the URL where you want to send the search query -->
        <input type="text" id="search" name="q" placeholder="Search">
       </form>
      <h3>Work To Do</h3>
      </div>

    <div class="rectangle2">
   <h4>Work Assign</h4>
    </div>
    
    <script>
        function assignTask(employeeId) {
            const taskSelect = document.getElementById(`taskSelect${employeeId}`);
            const selectedTask = taskSelect.value;
            
            if (selectedTask !== 'none') {
                
                alert(`Assigned Task '${selectedTask}' to Employee ID ${employeeId}`);
            } else {
                alert('Please select a task to assign.');
            }
        }
       
    </script>
    <script>
          function to_task() {
    $.post("pages/taskdone/task.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
function to_dash() {
    $.post("pages/dashboard/dashboard.php", {}, function (data) {
     $("#contents").html(data);  
        });
        
}
    </script>
    
</body>
</html>
