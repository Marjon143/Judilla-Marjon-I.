<!DOCTYPE html>
<html>
<head>
    <style>
        h1 {
            background: linear-gradient(90deg, red, white);
            color: transparent;
            text-align: center;
            margin: 0; /* Remove margin to have no spacing around h1 */
            padding: 100px 0; /* Add padding to control spacing above and below h1 */
            font-size: 70px;
            font-family: "Rhodium Libre", Times, serif;
            -webkit-background-clip: text;
            background-clip: text;
        }

        h2 {
            background: linear-gradient(90deg, red, white);
            color: transparent;
            text-align: center;
            padding: 25px 0; /* Add padding to control spacing above and below h1 */
            font-size: 48px;
            font-family: "Rhodium Libre", Times, serif;
            -webkit-background-clip: text;
            background-clip: text;
            margin: 10px 0; /* Add margin to control spacing above and below h2 */
        }
    </style>
</head>
<body>
    <h1>SYNCMINER INNOVATIONS</h1>
    <h2>CREATING A BETTER FUTURE</h2>
</body>
</html>
