<?php
    session_start();
     $_SESSION['signID']=1;

     echo 'Sign up Successful!';