<?php
    session_start();
     $_SESSION['userID']=1;

     echo 'Log in Successful!';